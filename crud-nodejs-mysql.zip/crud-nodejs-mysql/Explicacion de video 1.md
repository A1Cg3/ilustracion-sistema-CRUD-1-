-----------------------------------------------------------------------------------------------------------------------------------
## instalacion del servidor
-----------------------------------------------------------------------------------------------------------------------------------
# primero creamos el paquete de dependencias
npm init --yes
-----------------------------------------------------------------------------------------------------------------------------------
# Ahora instalamos los modulos que vamos a utilizar en el proyecto
npm install express mysql express-myconnection morgan ejs
-----------------------------------------------------------------------------------------------------------------------------------
# creamos la carpeta "src" y dentro el archivo "app.js" en el cual meteremos el siguiente codigo:
```bash
const express = require('express') # con este comando indcamos que requeriremos de express
const app = express(); # el servidor sera ejecutado en express

app.listen(3000, () => {
    console.log('server on port 3000');
}); # el servidor estara localizado en el puerto 3000
```
-----------------------------------------------------------------------------------------------------------------------------------
# ahora iniciamos con node el archivo "app.js"
node src/app.js
# nos aparecera error (Cannot GET /) pero es un mensaje de error de express con lo cual si funciona
-----------------------------------------------------------------------------------------------------------------------------------
# añadimos mas codigo a "app.js" y creamos dentro de la carpeta "src" una carpeta llamada "views"
```bash
const express = require('express'),
      path = require('path'),
      morgan = require('morgan'),
      mysql = require('mysql'),
      myConnection = require('express-myconnection');

const app = express();

// setings
app.set('port', process.env.PORT || 3000);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); # mediante el comando path.join se creara un vinvulo con la carpeta views

// middlewares
app.use(morgan('dev'));
app.use(myConnection(mysql, {
    host: 'localhost', # localizacion
    user: 'root',
    password: '1234',
    port: 3306, # puerto de conexion
    database: 'crudenodejsmysql' # base de datos que se utiliza
}, 'single')); # con estos datos vinvculamos mysql con el servidor

// routes


app.listen(3000, () => {
    console.log('server on port 3000');
});

```
-----------------------------------------------------------------------------------------------------------------------------------
# seguimos iniciando "app.js" con "nodemon"
nodemon src/app.jss
# tambien si no se tiene nodemon instalado globalmente podemos instalarlo unicamente para el proyecto con el comando: "npm install nodemon -D" y para usarlo entramos en el archivo "package.json" y añadimos el siguiente comando ejecutable:
  "scripts": {
    "dev": "nodemon src/app.js" #new
  },
# para ejecutar en la terminal solo tenemos que usar el siguiente comando Ç: "npm run dev" que hace que se ejecute el script con nombre "dev"
-----------------------------------------------------------------------------------------------------------------------------------
# ahora creamos otra carpeta en la raiz del proyecto que se llamara "database" en la cual crearemos una base de datos de sql
# dentro colocamos el siguiente codigo
-- creating database (Crear base de datos)
CREATE DATABASE crudenodejsmysql;

-- using database (usar base de datos)
use crudenodejsmysql

-- Creating a table (crear tabla en base de datos)
CREATE TABLE customer (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KAY,
    name VARCHAR(50) NOT NULL,
    address VARCHAR(100) NOT NULL,
    phone VARCHAR(15)
);

-- tp show all tables (mostrar tablas de base de datos)
SHOW TABLES;

-- to describe the table (motrar datos de customer)
describe customer;
-----------------------------------------------------------------------------------------------------------------------------------
# En "views" creamos un archivo llamado "cutomers.ejs", una carpeta "partials" y dendro de ella "_header.ejs" y "_footer.ejs
# dentro del archivo "customers.ejs" añadimos el siguiente codigo
```bash
<% include partials/_header %> # esto vincula el archivo "_header.ejs" el cual tiene el codigo que muerta en "ej.1" en este documento

<div class="container mt-5">
  <div class="row">
    <div class="col-md-7">
      <table class="table table-bordered table-hover">
        <thead>
          <tr>
            <td>n°</td>
            <td>Name</td>
            <td>Address</td>
            <td>Phone</td>
            <td>Actions</td>
          </tr>
        </thead>
        <tbody>
          <% if (data) { %>
            <% for(var i = 0; i < data.length; i++) { %>
              <tr>
                <td><%= (i + 1) %></td>
                <td><%= data[i].name %></td>
                <td><%= data[i].address %></td>
                <td><%= data[i].phone %></td>
                <td>
                  <a href="/update/<%= data[i].id %>" class="btn btn-info">Edit</a>
                  <a href="/delete/<%= data[i].id %>" class="btn btn-danger">Delete</a>
                </td>
              </tr>
            <% } %>
          <% } %>
        </tbody>
      </table>
    </div>
    <div class="col-md-5">
      <div class="card-body">

        <form action="/add" method="POST">
          <div class="form-group">
            <input type="text" name="name" placeholder="Name" class="form-control" autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="address" placeholder="Address" class="form-control">
          </div>
          <div class="form-group">
            <input type="text" name="phone" placeholder="Phone" class="form-control">
          </div>

          <button type="submit" class="btn btn-primary">
            save customer
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<% include partials/_footer %> # esto vincula el erchivo "_footer.ejs" que contiene el siguiente codigo en "ej.2"
```
# Con este codigo creamos la tabla donde introduciremos los datos de los clientes
## ej.1
```bash
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <title>Nodejs Mysql CRUD</title>
    <!-- NAVIGATION -->
    <link rel="stylesheet" href="https://bootswatch.com/4/lux/bootstrap.min.css">
  </head>
  <body>

    <!-- navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="/">CRUD Nodejs Mysql</a>
    </nav>
```
# Este codigo crea la cabecera de la pagina con fuentes y barra de navegacion
```
</body>
</html>
```
# Este codigo cierra el html
-----------------------------------------------------------------------------------------------------------------------------------
# ahora vamos a actualizar los codigos de los siguientes archivos
## customer.js
```
const router = require('express').Router();

const customerController = require('../controllers/customerController');

router.get('/', customerController.list);
router.post('/add', customerController.save);
router.get('/update/:id', customerController.edit);
router.post('/update/:id', customerController.update);
router.get('/delete/:id', customerController.delete);

module.exports = router;
```
# se vinculan los comandos utilizados en los archivos "customercontroller.ejs" y "customers_edit.ejs" (el cual se crea mas adelante)
## customercontroller.ejs
```
const controller = {};

controller.list = (req, res) => {
  req.getConnection((err, conn) => {
    conn.query('SELECT * FROM customer', (err, customers) => {
     if (err) {
      res.json(err);
     }
     res.render('customers', {
        data: customers
     });
    });
  });
};

controller.save = (req, res) => {
  const data = req.body;
  console.log(req.body)
  req.getConnection((err, connection) => {
    const query = connection.query('INSERT INTO customer set ?', data, (err, customer) => {
      console.log(customer)
      res.redirect('/');
    })
  })
};

controller.edit = (req, res) => {
  const { id } = req.params;
  req.getConnection((err, conn) => {
    conn.query("SELECT * FROM customer WHERE id = ?", [id], (err, rows) => {
      res.render('customers_edit', {
        data: rows[0]
      })
    });
  });
};

controller.update = (req, res) => {
  const { id } = req.params;
  const newCustomer = req.body;
  req.getConnection((err, conn) => {

  conn.query('UPDATE customer set ? where id = ?', [newCustomer, id], (err, rows) => {
    res.redirect('/');
  });
  });
};

controller.delete = (req, res) => {
  const { id } = req.params;
  req.getConnection((err, connection) => {
    connection.query('DELETE FROM customer WHERE id = ?', [id], (err, rows) => {
      res.redirect('/');
    });
  });
}
module.exports = controller;
```
# guardara y muestra los datos de los clientes en una tabla
## app.js
(line 27)app.use(express.urlencoded({extended: false}));
-----------------------------------------------------------------------------------------------------------------------------------
# dentro de la carpeta "partials" creamos un archivo llamado "customer_edit.ejs"
# agregamos el siguiente codigo:
<% include partials/_header %>
```
<div class="container mt-5">
  <div class="row">
    <div class="col-md-5 offset-md-3 card">
      <div class="card-body">
        <form action="/update/<%= data.id %>" method="POST">
          <div class="form-group">
            <input type="text" name="name" value="<%= data.name%>" placeholder="Name" class="form-control" autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="address" value="<%= data.address%>" placeholder="Address" class="form-control">
          </div>
          <div class="form-group">
            <input type="text" name="phone" value="<%= data.phone%>" placeholder="Phone" class="form-control">
          </div>

          <button type="submit" class="btn btn-primary">
            save customer
          </button>
        </form>
      </div>
    </div>
  </div>
</div>

<% include partials/_footer %>
```
# este codigo lo que hace es crear botones para poder borrar o actualizar los datos de un cliente guardado en la tabla y una tabla donde hay que hay que actualizar los datos
-----------------------------------------------------------------------------------------------------------------------------------
oooooooooooo  ooooo  ooooo      ooo
`888'     `8  `888'  `888b.     `8' 
 888           888    8 `88b.    8  
 888oooo8      888    8   `88b.  8  
 888    "      888    8     `88b.8  
 888           888    8       `888  
o888o         o888o  o8o        `8             